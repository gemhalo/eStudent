class MainApp < Netzke::Basepack::Panel
  #
end

