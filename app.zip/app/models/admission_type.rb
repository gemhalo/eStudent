class AdmissionType < ActiveRecord::Base
end
