class Campuse < ActiveRecord::Base
end
