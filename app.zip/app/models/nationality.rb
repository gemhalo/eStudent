class Nationality < ActiveRecord::Base
has_many :people

end
