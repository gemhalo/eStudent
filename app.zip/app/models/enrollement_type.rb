class EnrollementType < ActiveRecord::Base
end
