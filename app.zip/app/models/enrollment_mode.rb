class EnrollmentMode < ActiveRecord::Base
end
