class Admission < ActiveRecord::Base
end
