class FamilyBackground < ActiveRecord::Base
  belongs_to :applicant
end
