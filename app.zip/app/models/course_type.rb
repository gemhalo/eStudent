class CourseType < ActiveRecord::Base
  belongs_to :course
end
