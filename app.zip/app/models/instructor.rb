class Instructor < ActiveRecord::Base
	belongs_to :person
end
