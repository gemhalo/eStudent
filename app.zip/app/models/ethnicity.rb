class Ethnicity < ActiveRecord::Base
end
