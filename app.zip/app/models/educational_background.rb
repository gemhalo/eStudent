class EducationalBackground < ActiveRecord::Base

  belongs_to :student

end
