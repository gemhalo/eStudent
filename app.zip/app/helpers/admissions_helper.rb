module AdmissionsHelper
end
