module ApplicationHelper

end

