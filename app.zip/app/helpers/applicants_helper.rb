module ApplicantsHelper
end
