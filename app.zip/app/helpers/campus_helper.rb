module CampusHelper
end
