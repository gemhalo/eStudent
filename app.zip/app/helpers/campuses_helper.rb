module CampusesHelper
end
