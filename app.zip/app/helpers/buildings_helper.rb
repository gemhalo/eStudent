module BuildingsHelper
end
